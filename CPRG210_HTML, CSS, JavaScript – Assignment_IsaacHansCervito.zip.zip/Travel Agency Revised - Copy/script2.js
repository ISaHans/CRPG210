/**
 * Author: Isaac Hans Cervito
 * Date: October 1, 2024
 * Course: CPRG 210
 * Module: HTML, CSS, JavaScript – Assignment
 * Description: Main file for the Javascript code for the Main Page and Registration.
 */


// Image Redirection
let myWindow;
function openWin(cityId) {
  myWindow = window.open("", "", "width=500,height=500");
  myWindow.document.write("<p>You have 5 seconds to click!</p>");
 
  if (cityId === "istanbul") {
    myWindow.document.write('<p><a href="https://istanbul.com/">Visit The Istanbul Website</a></p>');
    myWindow.document.querySelector('a').onclick = function() {
      window.open("https://istanbul.com/", "_self");
      myWindow.close();
    };
  } else if (cityId === "newyork") {
    myWindow.document.write('<p><a href="https://www.nyc.gov/">Visit The New York Website</a></p>');
    myWindow.document.querySelector('a').onclick = function() {
        window.open("https://www.nyc.gov/" , "_self");
        myWindow.close();
    };
 } else if (cityId === "lossantos") {
    myWindow.document.write('<p><a href="https://www.rockstargames.com/newswire/article/ak14o88385k1a2/grand-theft-auto-v-official-website-update-visit-los-santos-blai.html">Visit The Los Santos Website</a></p>');
    myWindow.document.querySelector('a').onclick = function() {
        window.open("https://www.rockstargames.com/newswire/article/ak14o88385k1a2/grand-theft-auto-v-official-website-update-visit-los-santos-blai.html" , "_self");
        myWindow.close();
    };
} else if (cityId === "paris") {
    myWindow.document.write('<p><a href="https://parisjetaime.com/eng/">Visit The Paris Website</a></p>');
    myWindow.document.querySelector('a').onclick = function() {
        window.open("https://parisjetaime.com/eng/" , "_self");
        myWindow.close();
    };
} else if (cityId === "tokyo") {
    myWindow.document.write('<p><a href="https://www.gotokyo.org/en/index.html">Visit The Tokyo Website</a></p>');
    myWindow.document.querySelector('a').onclick = function() {
        window.open("https://www.gotokyo.org/en/index.html" , "_self");
        myWindow.close();
    };
  }

  setTimeout(closeWin, 5000);
}
function closeWin() {
    myWindow.close();
}



// Form Description
function focusFunction(formid) {
    const descriptions = document.querySelectorAll('.description');
    descriptions.forEach(function(desc) {
      desc.style.visibility = "hidden";
    });
    const box = document.getElementById(formid);
    box.style.display = "block";
    box.style.visibility = "visible"; 
}

function blurFunction() {
    const descriptions = document.querySelectorAll('.description');
    descriptions.forEach(function(desc) {
      desc.style.display = "none";
    });
}

// Submit Form 
function confirmation() {
    const button = document.querySelector("#confirm");

    if (button) {
        button.addEventListener("click", function(choice) {
            const userConfirmed = window.confirm("Do you wish to Submit?");
            if (userConfirmed === false) {
                choice.preventDefault();
            }
        });
    }
};

document.addEventListener("DOMContentLoaded", confirmation);